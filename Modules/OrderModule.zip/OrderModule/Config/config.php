<?php

return [
    'name' => 'OrderModule'
];
