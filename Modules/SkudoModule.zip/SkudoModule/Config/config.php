<?php

return [
    'name' => 'SkudoModule'
];
