@extends('commonmodule::layouts.master')

@section('title')
    {{__('warrantymodule::admin.insurance')}}
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('assets/admin/plugins/table/datatable/custom_dt_zero_config.css')}}"
          type="text/css">
@endsection



@section('content')



    <!--  BEGIN CONTENT PART  -->
    <div id="content" class="main-content">
        <div class="container">
            <div class="page-header">
                <div class="page-title">
                    <h3>{{__('warrantymodule::admin.insurance')}}</h3>
                    <div class="crumbs">
                        <ul id="breadcrumbs" class="breadcrumb">
                            <li><a href="{{url('/admin')}}"><i class="flaticon-home-fill"></i></a></li>
                            <li><a href="#">{{__('warrantymodule::admin.insurance')}}</a></li>
                        </ul>
                    </div>
                </div>
                <div class="page-title" style="float:right">
                    <a class="mt-4 btn btn-button-16 mr-2"
                       href="{{route('insurance.export')}}">
                        {{__('productmodule::category.download')}}
                    </a>
                </div>
            </div>

            <div class="row" id="cancel-row">

                <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <form action="{{route('insurance.index')}}" method="get">
                                <div class="row mt-5">
                                    <div class="col-md-3 col-xs-12">
                                        <input type="date" name="date" id="date_input" class="form-control">
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <button type="submit"
                                                class="btn btn-success">
                                            {{__('warrantymodule::warranty.all')}}
                                        </button>
                                        <button type="submit" name="filter" value="new"
                                                class="btn btn-info">
                                            {{__('warrantymodule::warranty.in_progress')}}
                                        </button>
                                        <button type="submit" name="filter" value="completed"
                                                class="btn btn-danger">
                                            {{__('warrantymodule::warranty.completed')}}
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="widget-content widget-content-area">
                            <div class="table-responsive mb-4">
                                <table id="zero-config" class="table table-hover table-bordered" style="width:100%">
                                    <thead>
                                    <tr class="text-center">
                                        <th>{{__('warrantymodule::insurance.quote_number')}}</th>
                                        <th>{{__('warrantymodule::insurance.company_name')}}</th>
                                        <th>{{__('warrantymodule::insurance.company_account')}}</th>
                                        <th>{{__('warrantymodule::insurance.user_name')}}</th>
                                        <th>{{__('warrantymodule::insurance.phone')}}</th>
                                        <th>{{__('warrantymodule::insurance.email')}}</th>
                                        <th>{{__('warrantymodule::insurance.dummy_text_1')}}</th>
                                        <th>{{__('warrantymodule::insurance.dummy_text_2')}}</th>
                                        <th>{{__('warrantymodule::insurance.dummy_text_3')}}</th>
                                        <th>{{__('warrantymodule::insurance.attachments')}}</th>
                                        <th>{{__('warrantymodule::insurance.usage_date')}}</th>
                                        <th>{{__('warrantymodule::insurance.sent_at')}}</th>
                                        <th>{{__('warrantymodule::insurance.replied_at')}}</th>
                                        <th>{{__('warrantymodule::insurance.status')}}</th>
                                        <th>{{__('warrantymodule::insurance.expire_date')}}</th>
                                        <th>{{__('warrantymodule::warranty.admin')}}</th>
                                        <th>{{__('productmodule::category.action')}}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($insurances as $insurance)
                                        <tr class="text-center">
                                            <td class="text-primary">{{$insurance->id}}</td>
                                            <td>{{$insurance->merchant->company_name ?? ''}}</td>
                                            <td>{{$insurance->merchant->account_number ?? ''}}</td>
                                            <td>{{$insurance->user_name}}</td>
                                            <td>{{$insurance->phone ? ($insurance->phone_code->code ?? '') : ''}} {{$insurance->phone}}</td>
                                            <td>{{$insurance->email}}</td>
                                            <td>{{$insurance->dummy_text_1}}</td>
                                            <td>{{$insurance->dummy_text_2}}</td>
                                            <td>{{$insurance->dummy_text_3}}</td>
                                            <td>
                                                <ul class="table-controls">
                                                    <li>
                                                        <a href="javascript: void(0)"
                                                           onclick="showAttachments('{{addslashes($insurance->attachments_str)}}')"
                                                           data-toggle="tooltip" data-placement="top"
                                                           title="Shot">
                                                            <i class="flaticon-view-1 bg-info p-1 text-white"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td>{!! $insurance->usage_date ? $insurance->usage_date->toDateString() . '<br>' . $insurance->usage_date->diffForHumans() : '' !!}</td>
                                            <td>{!! $insurance->created_at ? $insurance->created_at . '<br>' . $insurance->created_at->diffForHumans() : '' !!}</td>
                                            <td>{!! $insurance->replied_at ? $insurance->replied_at . '<br>' . humanReadableDiff($insurance->replied_at, $insurance->created_at) : '' !!}</td>
                                            <td>
                                                @if($insurance->isClosed())
                                                    <span
                                                        class="badge badge-dark">
                                                        {{__('warrantymodule::insurance.closed')}}
                                                    </span>
                                                @else
                                                    @if($insurance->status == 1)
                                                        <span
                                                            class="badge badge-success">{{__('warrantymodule::insurance.activated')}}</span>
                                                    @elseif($insurance->status == 0)
                                                        <span
                                                            class="badge badge-info">{{__('warrantymodule::insurance.pending')}}</span>
                                                    @else
                                                        <span
                                                            class="badge badge-danger">{{__('warrantymodule::insurance.rejected')}}</span>
                                                    @endif
                                                @endif
                                            </td>

                                            <td>{{$insurance->expire_date ? $insurance->expire_date->format('Y-m-d') : ''}}</td>
                                            <td>{{ $insurance->admin->name ?? '-' }}</td>
                                            <td>
                                                <ul class="table-controls">
                                                    <li>
                                                        <a href="{{route('insurance.edit', $insurance->id)}}"
                                                           data-toggle="tooltip" data-placement="top"
                                                           title="Edit">
                                                            <i class="flaticon-edit  bg-success p-1 text-white"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <form class="inline"
                                                              action="{{ route('insurance.destroy', $insurance->id) }}"
                                                              method="POST">
                                                            {{ method_field('DELETE') }} {!! csrf_field() !!}
                                                            <button class="unst" title="Delete" type="submit"
                                                                    onclick="return confirm('{{__("warrantymodule::admin.delete_warranty")}}')">
                                                                <i class="flaticon-delete  bg-danger p-1 text-white"></i>
                                                            </button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            @include('warrantymodule::admin.includes.attachment_modal')

        </div>
    </div>
    <!--  END CONTENT PART  -->
@stop

@section('js')
    @include('commonmodule::includes.swal')

    <script>
        let dTable = $('#zero-config').DataTable({
            "order": [[0, "desc"]],
            "lengthMenu": [100, 50, 20, 10],
            "language": {
                "paginate": {
                    "previous": "<i class='flaticon-arrow-left-1'></i>",
                    "next": "<i class='flaticon-arrow-right'></i>"
                },
                "info": "Showing page _PAGE_ of _PAGES_"
            },
            columnDefs: [{
                orderable: false,
                targets: 1
            }],
        });
    </script>
@endsection


