<?php

namespace Modules\WarrantyModule\Http\Controllers;

use App\Exports\InsuranceExport;
use Exception;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Maatwebsite\Excel\Facades\Excel;
use Modules\CommonModule\Helper\ApiResponseHelper;
use Modules\ConfigModule\Repository\ConfigRepository;
use Modules\WarrantyModule\Notifications\InsuranceRepliedNotification;
use Modules\WarrantyModule\Notifications\InsuranceReplyNotification;
use Modules\WarrantyModule\Repository\InsuranceRepository;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class InsuranceAdminController extends Controller
{
    use ApiResponseHelper;

    private InsuranceRepository $insuranceRepository;
    private ConfigRepository $configRepository;

    public function __construct(InsuranceRepository $insuranceRepository, ConfigRepository $configRepository)
    {
        $this->middleware('permission:insurance');
        $this->insuranceRepository = $insuranceRepository;
        $this->configRepository = $configRepository;
    }

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return Renderable
     */
    public function index(Request $request): Renderable
    {
        $insurances = $this->insuranceRepository->query();
        if ($request->get('filter') == 'completed')
            $insurances->where('status', '!=', 0)->get();
        elseif ($request->get('filter') == 'new')
            $insurances->where('status', 0);

        if ($request->get('date'))
            $insurances->whereDate('created_at', $request->get('date'));

        $insurances = $insurances->with(['admin', 'warranties'])->get();

        $this->insuranceRepository->markSeen($insurances);

        return view('warrantymodule::admin.insurance.index', compact('insurances'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id): Renderable
    {
        $insurance = $this->insuranceRepository->first(['id' => $id]);
        return view('warrantymodule::admin.insurance.edit', compact('insurance'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return RedirectResponse
     */
    public function update(Request $request, $id): RedirectResponse
    {
        $data = $request->validate([
            'status' => 'required|in:0,1,2',
            'reason' => 'required_if:status,2',
            'store_reason' => 'required_if:status,0',
        ]);

        if ($data['status'] == 1) {
            $data['expire_date'] = now()->addYears(intval($this->configRepository->getConfigsByKey(['insurance_years'])->first()->value_ar ?? 1));
        } else {
            $data['expire_date'] = null;
        }

        $data['admin_id'] = auth('admin')->id();

        $insurance = $this->insuranceRepository->first(['id' => $id]);

        if ($data['status'] == 1 || $data['status'] == 2) {
            if (is_null($insurance->replied_at)) $data['replied_at'] = now();
        } else {
            $data['replied_at'] = null;
        }

        if ($insurance->isClosed()) {
            return redirect()->back();
        }

        $insurance->update($data);

        if ($insurance->status == 1) {
//            $insurance->merchant->notify(new InsuranceRepliedNotification($insurance));
            notify($insurance->user, new InsuranceRepliedNotification($insurance));
        }

        notify($insurance->merchant, new InsuranceReplyNotification($insurance));

        return redirect()->route('insurance.index')->with('updated', 'updated');
    }

    /**
     * @return BinaryFileResponse
     */
    public function export(): BinaryFileResponse
    {
        return Excel::download(new InsuranceExport($this->insuranceRepository), 'Insurances.xlsx');
    }

    public function showModal($id)
    {
        $insurance = $this->insuranceRepository->first(['id' => $id]);
        return view('warrantymodule::admin.insurance.insurance-fields', compact('insurance'));
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return RedirectResponse
     * @throws Exception
     */
    public function destroy($id): RedirectResponse
    {
        $warranty = $this->insuranceRepository->first(['id' => $id]);
        $warranty->delete();
        return redirect()->route('insurance.index')->with('updated', 'updated');
    }
}
