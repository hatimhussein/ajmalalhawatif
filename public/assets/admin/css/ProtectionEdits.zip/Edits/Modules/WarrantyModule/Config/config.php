<?php

return [
    'name' => 'WarrantyModule'
];
