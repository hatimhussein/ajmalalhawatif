@extends('fronthomemodule::layouts.master')

@section('title')
    {{__('warrantymodule::insurance.insurance')}}
@endsection


@section('content')


    @include('fronthomemodule::content.breadCrumbs',['pages'=>[__('commonmodule::front.warranty')]])


    <!-- main-container -->
    <div class="main-container col2-right-layout">
        <div class="main container warranty-container">
            <div class="row w-attachments box">
                <div class="col-lg-4 col-md-4">
                    @if($insurance->front_image)
                        <h5> {{__('warrantymodule::insurance.front_image')}}</h5>
                        @if(is_video($insurance->front_image))
                            <video class="img-responsive" controls>
                                <source src="{{asset('images/warranty/'.$insurance->front_image)}}" type="video/mp4">
                                <source src="{{asset('images/warranty/'.$insurance->front_image)}}"
                                        type="video/quicktime">
                                Your browser does not support the video tag.
                            </video>
                        @else
                            <img class="img-responsive"
                                 src="{{asset('images/warranty/'.$insurance->front_image)}}"/>
                        @endif
                    @endif
                </div>
                <div class="col-lg-4 col-md-4">
                    @if($insurance->back_image)
                        <h5> {{__('warrantymodule::insurance.back_image')}}</h5>
                        @if(is_video($insurance->back_image))
                            <video class="img-responsive" controls>
                                <source src="{{asset('images/warranty/'.$insurance->back_image)}}" type="video/mp4">
                                <source src="{{asset('images/warranty/'.$insurance->back_image)}}"
                                        type="video/quicktime">
                                Your browser does not support the video tag.
                            </video>
                        @else
                            <img class="img-responsive"
                                 src="{{asset('images/warranty/'.$insurance->back_image)}}"/>
                        @endif
                    @endif
                </div>
                <div class="col-lg-4 col-md-4">
                    @if($insurance->warranty_image)
                        <h5> {{__('warrantymodule::insurance.warranty_image')}}</h5>
                        @if(is_video($insurance->warranty_image))
                            <video class="img-responsive" controls>
                                <source src="{{asset('images/warranty/'.$insurance->warranty_image)}}" type="video/mp4">
                                <source src="{{asset('images/warranty/'.$insurance->warranty_image)}}"
                                        type="video/quicktime">
                                Your browser does not support the video tag.
                            </video>
                        @else
                            <img class="img-responsive"
                                 src="{{asset('images/warranty/'.$insurance->warranty_image)}}" alt=""/>
                        @endif
                    @endif
                </div>
            </div>

            <div class="row w-user_info box">
                <div class="col-lg-12">
                    <div class="row mt-5">
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.user_name')}}:
                            </h5>
                            <span>{{ $insurance->user_name }}</span>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.phone')}}:
                            </h5>
                            <span>{{ $insurance->phone_code->code ?? '' }}{{ $insurance->phone }}</span>
                        </div>
                    </div>

                    <div class="row mt-5">
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.company_name')}}:
                            </h5>
                            <span>{{ $insurance->merchant->company_name ?? '' }}</span>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.company_account')}}:
                            </h5>
                            <span>{{ $insurance->merchant->account_number ?? '' }}</span>
                        </div>
                    </div>

                    <div class="row mt-5">
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.usage_date')}}:
                            </h5>
                            <span>{{ $insurance->usage_date ? $insurance->usage_date->toDateString() : '' }}</span>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.sent_at')}}:
                            </h5>
                            <span>{{ $insurance->created_at->diffForHumans() }}</span>
                        </div>
                    </div>

                    <div class="row mt-5">
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.dummy_text_1')}}:
                            </h5>
                            <span>{{ $insurance->dummy_text_1 }}</span>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.dummy_text_2')}}:
                            </h5>
                            <span>{{ $insurance->dummy_text_2 }}</span>
                        </div>
                    </div>

                    <div class="row mt-5">
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.dummy_text_3')}}:
                            </h5>
                            <span>{{ $insurance->dummy_text_3 }}</span>
                        </div>
                    </div>

                    <div class="row mt-5">
                        <div class="col-lg-12">
                            <h5>
                                {{__('warrantymodule::insurance.user_notes')}}:
                            </h5>
                            <span>{{ $insurance->user_notes }}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row w-response_info box">
                <div class="col-lg-12">
                    <div class="row mt-5">
                        {{--                            <div class="col-lg-6 col-md-6">--}}
                        {{--                                <h5>--}}
                        {{--                                    {{__('warrantymodule::insurance.device_name')}}:--}}
                        {{--                                </h5>--}}
                        {{--                                <span>{{ $insurance->device_name }}</span>--}}
                        {{--                            </div>--}}
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.replied_at')}}:
                            </h5>
                            <span>{{ $insurance->replied_at ? $insurance->replied_at->diffForHumans() : '' }}</span>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <h5>
                                {{__('warrantymodule::insurance.status').':'}}
                            </h5>
                            <span> {{__('warrantymodule::insurance.'.$insurance->status_locale)}} </span>
                        </div>
                    </div>

                    @if(($insurance->status == 0 && $insurance->store_reason) || ($insurance->status == 2 && $insurance->reason))
                        <div class="row mt-5">
                            <div class="col-lg-12">
                                <h5>
                                    {{__('warrantymodule::insurance.reason')}}:
                                </h5>
                                <span>{{ $insurance->status == 0 ? $insurance->store_reason : $insurance->reason }}</span>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <!--End main-container -->

@stop
